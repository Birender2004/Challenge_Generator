package practice.example.challengeGenerator.reposistory;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;
import practice.example.challengeGenerator.entity.dataWarehouse;


@Component
public interface interact  extends MongoRepository<dataWarehouse, String> {

}
