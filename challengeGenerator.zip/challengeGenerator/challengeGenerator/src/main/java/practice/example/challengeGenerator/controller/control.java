package practice.example.challengeGenerator.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import practice.example.challengeGenerator.entity.dataWarehouse;
import practice.example.challengeGenerator.service.agent;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/entry")
public class control {

    @Autowired
    private agent obj;

    @GetMapping("/get")
    public ResponseEntity<List<dataWarehouse>> fetch_challenge(){

        List<dataWarehouse> local= obj.fetchAll();

        if(!local.isEmpty()) {
            return new ResponseEntity<>(obj.fetchAll(), HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<String> fetchId(@PathVariable String id){
        Optional<dataWarehouse> local= obj.fetchId(id);

        if(local.isPresent()){
            if(local.get().getDiff_level() !=0) {
                return new ResponseEntity<>(local.get().getChallenge() + " \nDifficulty level: " + local.get().getDiff_level(), HttpStatus.OK);
            }
            else {
                return new ResponseEntity<>(local.get().getChallenge(), HttpStatus.OK);
            }
        }

        return new ResponseEntity<>("No such challenge with given id exists",HttpStatus.NOT_FOUND);
    }

    @PostMapping("/create")
    public ResponseEntity<String> add_challenge(@RequestBody dataWarehouse temp){

        try{
            obj.create(temp);
            return new ResponseEntity<>("Resource created",HttpStatus.CREATED);
        }
        catch (Exception e){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteChallenge(@PathVariable String id){
        Optional<dataWarehouse> local= obj.fetchId(id);

        if(local.isPresent()){
            obj.delete(id);

            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateChallenge(@PathVariable String id, @RequestBody dataWarehouse temp){
        Optional<dataWarehouse> local= obj.fetchId(id);

        if(local.isPresent()){
            obj.create(temp);

            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}
