package practice.example.challengeGenerator.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.lang.annotation.Documented;

@Document(collection = "challenge")
@Data
public class dataWarehouse {

    @Id
    String id;
    String challenge;
    int diff_level;

}
