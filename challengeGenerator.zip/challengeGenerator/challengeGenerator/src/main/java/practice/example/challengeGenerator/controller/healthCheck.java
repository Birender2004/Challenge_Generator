package practice.example.challengeGenerator.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/check")
public class healthCheck {

    @GetMapping("/load")
    public String load(){
        return "Application running properly";
    }
}
