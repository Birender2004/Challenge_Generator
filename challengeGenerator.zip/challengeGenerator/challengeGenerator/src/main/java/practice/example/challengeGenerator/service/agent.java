package practice.example.challengeGenerator.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import practice.example.challengeGenerator.entity.dataWarehouse;
import practice.example.challengeGenerator.reposistory.interact;

import java.util.List;
import java.util.Optional;

@Component
public class agent {

    @Autowired
    private interact obj;

    public List<dataWarehouse> fetchAll(){

        return obj.findAll();
    }

    public void create(dataWarehouse temp){

        obj.save(temp);
    }

    public Optional<dataWarehouse> fetchId(String id){

        return obj.findById(id);
    }

    public void delete(String id){

        obj.deleteById(id);
    }


}
