package practice.example.challengeGenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
